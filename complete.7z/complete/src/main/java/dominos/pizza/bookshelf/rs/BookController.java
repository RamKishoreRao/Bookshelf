package dominos.pizza.bookshelf.rs;

import java.util.ArrayList;
import java.util.Collection;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import dominos.pizza.bookshelf.bean.BookRequest;
import dominos.pizza.bookshelf.bean.BookResponse;
import dominos.pizza.bookshelf.bean.Books;
import dominos.pizza.bookshelf.bean.ErrorMessage;
import dominos.pizza.bookshelf.bean.Message;

@RestController
public class BookController {

	ArrayList<Books> bookArLst = new ArrayList<Books>();

	@RequestMapping(value = "/allbooks", produces = "application/json", method = RequestMethod.GET)
	@ResponseBody
	public BookResponse getAllBooks() {
		Books book = new Books();
		BookResponse bookResponse = new BookResponse();
		Message message = new Message();
		
		if(bookArLst.size()<1) {
			
			message.setServiceStatus("SUCCESS");
			message.setServiceMessage("Add books to shelf");
			bookResponse.setMessage(message);
			return bookResponse;
		}
		bookResponse.setBooksList(bookArLst);
		message.setServiceStatus("SUCCESS");
		message.setServiceMessage("Here are the List of book");
		bookResponse.setMessage(message);
		return bookResponse;
	}

	@RequestMapping(value = "/onebook/{bookName}", method = RequestMethod.GET)
	@ResponseBody
	public BookResponse getOneBook(@PathVariable("bookName") String bookName) {
		
		Books book = new Books();
		BookResponse bookResponse = new BookResponse();
		Message message = new Message();
		ErrorMessage errmessage = new ErrorMessage();	

		book =  findBookName(bookArLst,bookName);
		if ( bookArLst.size()<1||book==null) {
			message.setServiceStatus("SUCCESS");
			errmessage.setErrorCode("BKNOT");
			errmessage.setMessage("No book is available with this book name ");
			message.setErrMsg(errmessage);
			bookResponse.setMessage(message);			
			return bookResponse;
		}
		ArrayList<Books> bklist = new ArrayList<Books>();
		bklist.add(book);
		bookResponse.setBooksList(bklist);
		message.setServiceStatus("SUCCESS");
		bookResponse.setMessage(message);
		return bookResponse;
	}

	@RequestMapping(value = "/addBook", method = RequestMethod.POST)
	@ResponseBody
	public BookResponse addABook(@RequestBody BookRequest bookRequest) {
		
		Books book = new Books();
		BookResponse bookResponse = new BookResponse();
		Message message = new Message();
		book.setBookId(bookRequest.getBookId());
		book.setBookName(bookRequest.getBookName());    
		book.setAuthorName(bookRequest.getAuthorName());
		book.setPublisherName(bookRequest.getPublisherName());
		book.setReleaseYear(bookRequest.getReleaseYear());
		bookArLst.add(book);
		message.setServiceStatus("SUCCESS");
		message.setServiceMessage("Book " + book.getBookName()+" saved");
		bookResponse.setMessage(message);
		return bookResponse;
	}

	@RequestMapping(value = "/deletebook/{bookName}", method = RequestMethod.DELETE)
	@ResponseBody
	public BookResponse getDeleteBook(@PathVariable("bookName") String bookName) {
		
		BookResponse bookResponse = new BookResponse();
		Message message = new Message();
		Books book = findBookName(bookArLst,bookName);
		if (book==null) {			
			message.setServiceStatus("SUCCESS");
			message.setServiceMessage("No book is available with this ");
			bookResponse.setMessage(message);
			return bookResponse;
		}
		bookArLst.removeIf(books -> bookName.contains(books.getBookName()));
		message.setServiceStatus("SUCCESS");
		message.setServiceMessage("Book  "+bookName+ " removed");
		bookResponse.setMessage(message);
		return bookResponse;
	}
	
	public static Books findBookName(Collection<Books> booksList, String bookName) {
	    return booksList.stream().filter(book -> bookName.equals(book.getBookName())).findFirst().orElse(null);
	}
	
	
}


