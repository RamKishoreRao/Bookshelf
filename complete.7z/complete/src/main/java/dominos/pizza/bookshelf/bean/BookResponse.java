package dominos.pizza.bookshelf.bean;

import java.util.ArrayList;

public class BookResponse {
	
	private ArrayList<Books> booksList;
	private Message message;
	
	public ArrayList<Books> getBooksList() {
		return booksList;
	}
	public void setBooksList(ArrayList<Books> booksList) {
		this.booksList = booksList;
	}
	public Message getMessage() {
		return message;
	}
	public void setMessage(Message message) {
		this.message = message;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((booksList == null) ? 0 : booksList.hashCode());
		result = prime * result + ((message == null) ? 0 : message.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		BookResponse other = (BookResponse) obj;
		if (booksList == null) {
			if (other.booksList != null)
				return false;
		} else if (!booksList.equals(other.booksList))
			return false;
		if (message == null) {
			if (other.message != null)
				return false;
		} else if (!message.equals(other.message))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "BookResponse [booksList=" + booksList + ", message=" + message + "]";
	}
	
	

}
