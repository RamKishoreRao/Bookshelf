package dominos.pizza.bookshelf.bean;

public class Message {

	private String serviceStatus;
	private String serviceMessage;
	private ErrorMessage errMsg;
	
	public String getServiceStatus() {
		return serviceStatus;
	}
	public void setServiceStatus(String serviceStatus) {
		this.serviceStatus = serviceStatus;
	}
	public String getServiceMessage() {
		return serviceMessage;
	}
	public void setServiceMessage(String serviceMessage) {
		this.serviceMessage = serviceMessage;
	}
	public ErrorMessage getErrMsg() {
		return errMsg;
	}
	public void setErrMsg(ErrorMessage errMsg) {
		this.errMsg = errMsg;
	}
	
	@Override
	public String toString() {
		return "Message [serviceStatus=" + serviceStatus + ", serviceMessage=" + serviceMessage + ", errMsg=" + errMsg
				+ "]";
	}
	
	
	
}
